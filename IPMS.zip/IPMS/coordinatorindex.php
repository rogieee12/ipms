<?php
session_start();
include 'Actions/connection.php';
if($_SESSION['u']==''){
     header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IPMS | Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
</head>
<style>
  .sidebar-dark-primary{
    background-color: #002147 !important;
  }
  .navbar-white{
    background-color: #507d2a !important;
  }
</style>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
  
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
     
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">IPMS</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
           <?php 
            $acc=mysqli_query($connection,"SELECT * FROM accounts WHERE username='".$_SESSION['u']."'");
            $rows=mysqli_fetch_array($acc);
          ?>
          <a href="#" class="d-block"><?php echo $rows[3]. " ".substr($rows[4],0,1).". ".$rows[2];?></a>
        </div>
      </div>
<!-- Sidebar Menu -->
<nav class="mt-2">
  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    <li class="nav-item menu-open">
      <a href="#" class="nav-link active">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>Dashboard</p>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fas fa-cogs"></i>
        <p>Setup <i class="fas fa-angle-left right"></i></p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="pages/Consumables2.php" class="nav-link">
            <i class="fas fa-clock nav-icon"></i>
            <p>Rendered Hour</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="pages/Category.php" class="nav-link">
            <i class="fas fa-tags nav-icon"></i>
            <p>Category</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="pages/EvaluationQuestion.php" class="nav-link">
            <i class="fas fa-list nav-icon"></i>
            <p>Evaluation Matrix</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="pages/Scale.php" class="nav-link">
            <i class="fas fa-balance-scale nav-icon"></i>
            <p>Scale</p>
          </a>
        </li>
      </ul>
    </li>
    
    <li class="nav-item">
      <a href="pages/AssignStudent.php" class="nav-link">
        <i class="fas fa-user-graduate nav-icon"></i>
        <p>Deploy Interns</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="pages/ClassToAnnounce.php" class="nav-link">
        <i class="fas fa-bullhorn nav-icon"></i>
        <p>Announcement</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="pages/Chat.php" class="nav-link">
        <i class="fas fa-comments nav-icon"></i>
        <p>Chat</p>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="#" class="nav-link">
        <i class="nav-icon fas fa-chart-bar"></i>
        <p>Reports <i class="fas fa-angle-left right"></i></p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="pages/Listofstudents.php" class="nav-link">
            <i class="fas fa-users nav-icon"></i>
            <p>Student Intern</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="pages/ViewAccomplishment.php" class="nav-link">
            <i class="fas fa-trophy nav-icon"></i>
            <p>Accomplishment</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="pages/ReviewEvaluation.php" class="nav-link">
            <i class="fas fa-star nav-icon"></i>
            <p>Evaluation</p>
          </a>
        </li>
      </ul>
    </li>
    
    <li class="nav-item">
      <a href="Actions/logout.php" class="nav-link">
        <i class="fas fa-sign-out-alt nav-icon"></i>
        <p>Logout</p>
      </a>
    </li>
  </ul>
</nav>
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="coordinatorindex.php">Home</a></li>
             
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <?php
                  $q=mysqli_query($connection,"SELECT COUNT(*) FROM studentlist WHERE coordinator='".$_SESSION['u']."'");
                  $rows=mysqli_fetch_array($q);
                ?>
                <h3><?php echo $rows[0];?></h3>
                <p>Interns</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <?php
                  $q=mysqli_query($connection,"SELECT COUNT(*) FROM supervisors WHERE coordinator='".$_SESSION['u']."'");
                  $rows=mysqli_fetch_array($q);
                ?>
                <h3><?php echo $rows[0];?></h3>
                <p>Supervisor</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
             
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
               <?php
                  $q=mysqli_query($connection,"SELECT COUNT(*) FROM Accomplishment INNER JOIN studentlist ON accomplishment.username=studentlist.student WHERE studentlist.coordinator='".$_SESSION['u']."'");
                  $rows=mysqli_fetch_array($q);
                ?>
                <h3><?php echo $rows[0];?></h3>
                <p>Accomplishment</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
             
            </div>
          </div>
     
     <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
               <?php
                  $q=mysqli_query($connection,"SELECT COUNT(*) FROM Accomplishment INNER JOIN studentlist ON accomplishment.username=studentlist.student WHERE studentlist.coordinator='".$_SESSION['u']."'");
                  $rows=mysqli_fetch_array($q);
                ?>
                <h3><?php echo $rows[0];?></h3>
                <p>Attendances</p>
              </div>
              <div class="icon">
                <i class="ion ion-folder"></i>
              </div>
             
            </div>
          </div>
     


        <div class="row">
            <div class="col-12">
        
          <div>
              <canvas id="barChart" width="900" height="400"></canvas>
          </div>

            <!-- /.card -->
            </div>
        </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
        <div class="row">
        
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">
            <!-- /.card -->
          </section>
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php 
    include('includes/footer.html');
  ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- ChartJS -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</body>
</html>
   <script>
         $(document).ready(function() {
            // Fetch data from the PHP file
            $.ajax({
                url: 'Actions/bargraph.php', // Replace with the PHP file URL
                method: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.error) {
                        console.error("Error: ", response.error);
                        return;
                    }

                    // Extract course descriptions and total accomplishments
                    const labels = response.map(item => item.crs_desc);
                    const values = response.map(item => item.total_accomplishments);

                    // Render bar graph
                    const ctx = document.getElementById('barChart').getContext('2d');
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Total Accomplishments',
                                data: values,
                                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            responsive: true,
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error: ", error);
                }
            });
        });
    </script>
