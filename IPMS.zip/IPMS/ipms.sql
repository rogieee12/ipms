-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2025 at 01:30 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ipms`
--

-- --------------------------------------------------------

--
-- Table structure for table `accomplishment`
--

CREATE TABLE `accomplishment` (
  `ac_id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `accomplishment` longtext NOT NULL,
  `date_time` varchar(100) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  `crs_id` int(10) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accomplishment`
--

INSERT INTO `accomplishment` (`ac_id`, `username`, `accomplishment`, `date_time`, `remarks`, `crs_id`, `status`) VALUES
(73, 'mickeejacobe@sjcbi.edu.ph', 'testing', '2025-02-02', 'Animal ka ketdi', 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `username` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `profile` blob NOT NULL,
  `crs_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`username`, `lastname`, `firstname`, `middlename`, `contact`, `gender`, `profile`, `crs_id`) VALUES
('admin', 'Dela Cruz', 'Rogelio', 'A', '09465456131', '', '', 0),
('coordinator@sjcbi.edu.ph', 'Ziganay', 'Cielo Vee', 'Plata', '09264604291', '', '', 2),
('marissapalomares@sjcbi.edu.ph', 'Palomares', 'Marissa', 'Quilang', '09264604229', '', '', 0),
('mickeejacobe@sjcbi.edu.ph', 'Jacobe', 'Mickee', 'Tabubuca', '09264604291', '', '', 2);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `a_id` int(11) NOT NULL,
  `message` varchar(9999) NOT NULL,
  `date_posted` varchar(100) NOT NULL,
  `attachment` varchar(200) NOT NULL,
  `posted_by` varchar(100) NOT NULL,
  `supervisor` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`a_id`, `message`, `date_posted`, `attachment`, `posted_by`, `supervisor`) VALUES
(28, ' sdfg', '2024-11-30', '', 'supervisor@gmail.com', 'supervisor@gmail.com'),
(29, ' okay', '2024-11-30', '', 'coordinator@gmail.com', 'supervisor@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `att_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `time_in_AM` varchar(100) NOT NULL,
  `time_in_PM` varchar(100) NOT NULL,
  `time_out_AM` varchar(100) NOT NULL,
  `time_out_PM` varchar(100) NOT NULL,
  `Ext_IN` varchar(100) NOT NULL,
  `Ext_OUT` varchar(100) NOT NULL,
  `d_date` varchar(10) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`att_id`, `username`, `time_in_AM`, `time_in_PM`, `time_out_AM`, `time_out_PM`, `Ext_IN`, `Ext_OUT`, `d_date`, `status`) VALUES
(9, 'mickeejacobe@sjcbi.edu.ph', '12:18 PM', '12:18 PM', '12:18 PM', '12:18 PM', '12:18 PM', '12:18 PM', '2025-02-02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `com_id` int(100) NOT NULL,
  `a_id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `comments` varchar(9999) NOT NULL,
  `datetime` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`com_id`, `a_id`, `username`, `comments`, `datetime`) VALUES
(25, 24, 'student1@gmail.com', 'asdasd', '2024-09-25 09:47:51'),
(26, 24, 'student1@gmail.com', 'aaaa', '2024-09-25 09:48:26'),
(27, 28, 'student@gmail.com', 'yes maam', '2024-11-30 16:42:43');

-- --------------------------------------------------------

--
-- Table structure for table `consumable`
--

CREATE TABLE `consumable` (
  `cons_id` int(11) NOT NULL,
  `crs_id` int(100) NOT NULL,
  `hrs` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `consumable`
--

INSERT INTO `consumable` (`cons_id`, `crs_id`, `hrs`) VALUES
(4, 2, '600'),
(7, 3, '600');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `crs_id` int(100) NOT NULL,
  `crs_desc` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `section` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`crs_id`, `crs_desc`, `year`, `section`) VALUES
(2, 'BSIT', '4', 'A'),
(3, 'BSIT', '4', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `deparment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`dept_id`, `deparment`) VALUES
(1, 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `evalquestions`
--

CREATE TABLE `evalquestions` (
  `eq_id` int(100) NOT NULL,
  `qcat_id` int(100) NOT NULL,
  `question` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `evalquestions`
--

INSERT INTO `evalquestions` (`eq_id`, `qcat_id`, `question`) VALUES
(2, 3, ' The OJT Student has sufficient academic knowledge to contribute to the organization.'),
(3, 3, 'He/She Understands concepts and applies knowledge on the job'),
(4, 3, 'He/She has technical skills appropriate to the level in school and job requirements.'),
(5, 4, 'The OJT Student set realistic goals.'),
(6, 4, 'He/She Organizes and prioritize assigned tasks.'),
(7, 4, 'He/She is able to manage multiple assignments.'),
(8, 5, 'The OJT student completes tasks accurately to detail and compliance to company standards.'),
(9, 6, 'The OJT Student consistently demonstrates a proactive nature.');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `receiver` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `message`, `timestamp`) VALUES
(160, 'marissapalomares@sjcbi.edu.ph', 'coordinator@sjcbi.edu.ph', 'hello', '2024-12-14 14:28:02'),
(161, 'marissapalomares@sjcbi.edu.ph', 'coordinator@sjcbi.edu.ph', 'testing', '2024-12-14 14:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `quescategory`
--

CREATE TABLE `quescategory` (
  `qcat_id` int(11) NOT NULL,
  `Category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quescategory`
--

INSERT INTO `quescategory` (`qcat_id`, `Category`) VALUES
(3, 'Academic Knowledge & Technical Skills'),
(5, 'Quality of Work'),
(6, 'Initiative');

-- --------------------------------------------------------

--
-- Table structure for table `responses`
--

CREATE TABLE `responses` (
  `response_id` int(100) NOT NULL,
  `eq_id` int(100) NOT NULL,
  `rating` int(100) NOT NULL,
  `student` varchar(100) NOT NULL,
  `xdate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `responses`
--

INSERT INTO `responses` (`response_id`, `eq_id`, `rating`, `student`, `xdate`) VALUES
(68, 2, 5, 'student@gmail.com', '2024-11-30'),
(69, 3, 4, 'student@gmail.com', '2024-11-30'),
(70, 4, 4, 'student@gmail.com', '2024-11-30'),
(71, 5, 5, 'student@gmail.com', '2024-11-30'),
(72, 6, 4, 'student@gmail.com', '2024-11-30'),
(73, 7, 4, 'student@gmail.com', '2024-11-30'),
(74, 8, 5, 'student@gmail.com', '2024-11-30'),
(75, 9, 4, 'student@gmail.com', '2024-11-30'),
(76, 2, 5, 'student1@gmail.com', '2024-11-30'),
(77, 3, 5, 'student1@gmail.com', '2024-11-30'),
(78, 4, 5, 'student1@gmail.com', '2024-11-30'),
(79, 5, 5, 'student1@gmail.com', '2024-11-30'),
(80, 6, 5, 'student1@gmail.com', '2024-11-30'),
(81, 7, 5, 'student1@gmail.com', '2024-11-30'),
(82, 8, 5, 'student1@gmail.com', '2024-11-30'),
(83, 9, 5, 'student1@gmail.com', '2024-11-30'),
(84, 2, 5, 'student1@gmail.com', '2024-11-30'),
(85, 3, 5, 'student1@gmail.com', '2024-11-30'),
(86, 4, 4, 'student1@gmail.com', '2024-11-30'),
(87, 5, 5, 'student1@gmail.com', '2024-11-30'),
(88, 6, 5, 'student1@gmail.com', '2024-11-30'),
(89, 7, 5, 'student1@gmail.com', '2024-11-30'),
(90, 8, 5, 'student1@gmail.com', '2024-11-30'),
(91, 9, 5, 'student1@gmail.com', '2024-11-30'),
(92, 2, 5, 'mickeejacobe@sjcbi.edu.ph', '2024-12-01'),
(93, 3, 4, 'mickeejacobe@sjcbi.edu.ph', '2024-12-01'),
(94, 4, 4, 'mickeejacobe@sjcbi.edu.ph', '2024-12-01'),
(95, 6, 4, 'mickeejacobe@sjcbi.edu.ph', '2024-12-01'),
(96, 7, 4, 'mickeejacobe@sjcbi.edu.ph', '2024-12-01'),
(97, 2, 5, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(98, 3, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(99, 4, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(100, 5, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(101, 6, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(102, 7, 5, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(103, 8, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02'),
(104, 9, 4, 'mickeejacobe@sjcbi.edu.ph', '2025-02-02');

-- --------------------------------------------------------

--
-- Table structure for table `scale`
--

CREATE TABLE `scale` (
  `scale_id` int(11) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scale`
--

INSERT INTO `scale` (`scale_id`, `description`) VALUES
(1, 'POOR'),
(2, 'FAIR'),
(3, 'NEUTRAL'),
(4, 'SATISFACTORY'),
(5, 'VERY SATISFACTORY');

-- --------------------------------------------------------

--
-- Table structure for table `schoolyear`
--

CREATE TABLE `schoolyear` (
  `sy_id` int(100) NOT NULL,
  `sy_desc` varchar(20) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schoolyear`
--

INSERT INTO `schoolyear` (`sy_id`, `sy_desc`, `status`) VALUES
(1, '2024-2025', 1);

-- --------------------------------------------------------

--
-- Table structure for table `security`
--

CREATE TABLE `security` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `acctype` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `security`
--

INSERT INTO `security` (`username`, `password`, `acctype`) VALUES
('admin', 'admin', 'Administrator'),
('coordinator@sjcbi.edu.ph', '12345', 'Coordinator'),
('marissapalomares@sjcbi.edu.ph', 'aCbvHed7', 'Supervisor'),
('mickeejacobe@sjcbi.edu.ph', '12345', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `studentlist`
--

CREATE TABLE `studentlist` (
  `studlist_id` int(11) NOT NULL,
  `student` varchar(100) NOT NULL,
  `supervisor` varchar(100) NOT NULL,
  `coordinator` varchar(100) NOT NULL,
  `sy_id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentlist`
--

INSERT INTO `studentlist` (`studlist_id`, `student`, `supervisor`, `coordinator`, `sy_id`) VALUES
(43, 'mickeejacobe@sjcbi.edu.ph', 'marissapalomares@sjcbi.edu.ph', 'coordinator@sjcbi.edu.ph', 0);

-- --------------------------------------------------------

--
-- Table structure for table `supervisors`
--

CREATE TABLE `supervisors` (
  `sup_id` int(11) NOT NULL,
  `supervisor` varchar(100) NOT NULL,
  `coordinator` varchar(100) NOT NULL,
  `Agency` varchar(100) NOT NULL,
  `office_name` varchar(100) NOT NULL,
  `sy_id` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supervisors`
--

INSERT INTO `supervisors` (`sup_id`, `supervisor`, `coordinator`, `Agency`, `office_name`, `sy_id`) VALUES
(12, 'supervisor@gmail.com', 'coordinator@gmail.com', 'Saint Joseph College of Baggao', 'CICS Office', 1),
(14, 'marissapalomares@sjcbi.edu.ph', 'coordinator@sjcbi.edu.ph', 'Saint Joseph College of Baggao', 'VP Admin', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accomplishment`
--
ALTER TABLE `accomplishment`
  ADD PRIMARY KEY (`ac_id`);

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`att_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`com_id`);

--
-- Indexes for table `consumable`
--
ALTER TABLE `consumable`
  ADD PRIMARY KEY (`cons_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`crs_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `evalquestions`
--
ALTER TABLE `evalquestions`
  ADD PRIMARY KEY (`eq_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quescategory`
--
ALTER TABLE `quescategory`
  ADD PRIMARY KEY (`qcat_id`);

--
-- Indexes for table `responses`
--
ALTER TABLE `responses`
  ADD PRIMARY KEY (`response_id`);

--
-- Indexes for table `scale`
--
ALTER TABLE `scale`
  ADD PRIMARY KEY (`scale_id`);

--
-- Indexes for table `schoolyear`
--
ALTER TABLE `schoolyear`
  ADD PRIMARY KEY (`sy_id`);

--
-- Indexes for table `security`
--
ALTER TABLE `security`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `studentlist`
--
ALTER TABLE `studentlist`
  ADD PRIMARY KEY (`studlist_id`);

--
-- Indexes for table `supervisors`
--
ALTER TABLE `supervisors`
  ADD PRIMARY KEY (`sup_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accomplishment`
--
ALTER TABLE `accomplishment`
  MODIFY `ac_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `att_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `com_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `consumable`
--
ALTER TABLE `consumable`
  MODIFY `cons_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `crs_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `evalquestions`
--
ALTER TABLE `evalquestions`
  MODIFY `eq_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `quescategory`
--
ALTER TABLE `quescategory`
  MODIFY `qcat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `responses`
--
ALTER TABLE `responses`
  MODIFY `response_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `scale`
--
ALTER TABLE `scale`
  MODIFY `scale_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `schoolyear`
--
ALTER TABLE `schoolyear`
  MODIFY `sy_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `studentlist`
--
ALTER TABLE `studentlist`
  MODIFY `studlist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `supervisors`
--
ALTER TABLE `supervisors`
  MODIFY `sup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
