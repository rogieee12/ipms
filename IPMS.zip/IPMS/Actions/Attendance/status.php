<?php
session_start();
include('../Actions/connection.php');

$username = $_SESSION['u'];

$query = "SELECT * FROM attendance WHERE username='$username' AND d_date=CURDATE() ORDER BY att_id DESC LIMIT 1";
$result = mysqli_query($connection, $query);
$row = mysqli_fetch_assoc($result);

$hasTimeInAM = !empty($row['time_in_AM']);
$hasTimeOutAM = !empty($row['time_out_AM']);
$hasTimeInPM = !empty($row['time_in_PM']);
$hasTimeOutPM = !empty($row['time_out_PM']);

$response = [
    "success" => true,
    "hasTimeInAM" => $hasTimeInAM,
    "hasTimeOutAM" => $hasTimeOutAM,
    "hasTimeInPM" => $hasTimeInPM,
    "hasTimeOutPM" => $hasTimeOutPM,
    "canTimeInAM" => !$hasTimeInAM,
    "canTimeOutAM" => $hasTimeInAM && !$hasTimeOutAM,
    "canTimeInPM" => $hasTimeOutAM && !$hasTimeInPM,
    "canTimeOutPM" => $hasTimeInPM && !$hasTimeOutPM
];

header('Content-Type: application/json');
echo json_encode($response);
?>
