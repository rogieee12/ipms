<?php 
session_start();
include('../connection.php');

$username = $_SESSION['u'];
$current_date = date('Y-m-d');
date_default_timezone_set('Asia/Manila'); // Set timezone to Philippines
$current_time = date('g:i A');

echo "Current Time: " . $current_time;



$q = mysqli_query($connection, "SELECT * FROM attendance WHERE username='$username' AND d_date='$current_date' ORDER BY att_id DESC");
$rows = mysqli_fetch_array($q);

if (mysqli_num_rows($q) == 0) {
    // Insert new attendance record with time_in_AM
    mysqli_query($connection, "INSERT INTO attendance (username, time_in_AM, d_date, status) VALUES ('$username', '$current_time', '$current_date', '0')");
} else {
    // Corrected priority of conditions
    if (empty($rows['time_out_AM']) && !empty($rows['time_in_AM'])) {
        // Make sure time_out_AM is recorded before time_in_PM
        mysqli_query($connection, "UPDATE attendance SET time_out_AM='$current_time' WHERE att_id='{$rows['att_id']}'");
    } else if (empty($rows['time_in_PM']) && !empty($rows['time_out_AM'])) {
        mysqli_query($connection, "UPDATE attendance SET time_in_PM='$current_time' WHERE att_id='{$rows['att_id']}'");
    } else if (empty($rows['time_out_PM']) && !empty($rows['time_in_PM'])) {
        mysqli_query($connection, "UPDATE attendance SET time_out_PM='$current_time' WHERE att_id='{$rows['att_id']}'");
    } else if (empty($rows['Ext_IN']) && !empty($rows['time_out_PM'])) {
       
    }
}
?>
