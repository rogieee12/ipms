<?php 
include('../connection.php');

mysqli_query($connection,"UPDATE attendance set status='1' WHERE att_id='".$_POST['id']."'");

?>