<?php
session_start();    
include('../connection.php');

$q = mysqli_query($connection, "SELECT * FROM attendance");
$rows = mysqli_fetch_array($q);

// Example times
$time_in_AM = trim($rows[2]);
$time_out_AM = trim($rows[3]);
$time_in_PM = trim($rows[4]);
$time_out_PM = trim($rows[5]);
$ext_int = trim($rows[6]);
$ext_out = trim($rows[7]);

// Function to calculate difference in hours and minutes
function calculate_time_difference($start_time, $end_time) {
    $start = new DateTime($start_time);
    $end = new DateTime($end_time);
    $interval = $start->diff($end);

    // Convert hours and minutes to total hours (decimal format)
    return $interval->h + ($interval->i / 60);
}

// Calculate each segment
$am_hours = calculate_time_difference($time_in_AM, $time_out_AM);
$pm_hours = calculate_time_difference($time_in_PM, $time_out_PM);
$ext_hours = calculate_time_difference($ext_int, $ext_out);


$total_hours = $am_hours + $pm_hours + $ext_hours;


echo number_format($total_hours, 2) . " hours";
?>
