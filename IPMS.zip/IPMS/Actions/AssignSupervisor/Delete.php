<?php
	include'../connection.php';
	mysqli_query($connection,"DELETE FROM supervisors WHERE sup_id='".$_POST['id']."'");
?>