<?php
	session_start();
	include'../connection.php';
	$q=mysqli_query($connection,"SELECT * FROM schoolyear WhERE Status='0'");
	$rows=mysqli_fetch_array($q);

	if($_POST['p_id']==''){
		mysqli_query($connection,"INSERT into supervisors values (null,'".$_POST['AccountType']."','".$_SESSION['u']."','".$_POST['Agency']."','".$_POST['Office']."','".$rows[0]."')");
	}
	else{
		mysqli_query($connection,"UPDATE supervisors set supervisor='".$_POST['AccountType']."', Agency='".$_POST['Agency']."',office_name='".$_POST['Office']."' WHERE sup_id='".$_POST['p_id']."'");
	}
	

?>