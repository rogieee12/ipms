<?php
	include'../connection.php';
	if($_POST['p_id']==''){
		mysqli_query($connection,"INSERT into courses values (null,'".$_POST['Crs']."','".$_POST['Year']."','".$_POST['Section']."')");

	}
	else{
		mysqli_query($connection,"UPDATE courses set crs_desc='".$_POST['Crs']."', year='".$_POST['Year']."', section='".$_POST['Section']."' WHERE crs_id='".$_POST['p_id']."'");
	}
	

?>