<?php
	include'../connection.php';
	if($_POST['p_id']==''){
		mysqli_query($connection,"INSERT into consumable values (null,'".$_POST['Crs']."','".$_POST['Hrs']."')");

	}
	else{
		mysqli_query($connection,"UPDATE consumable set crs_id='".$_POST['Crs']."',Hrs='".$_POST['Hrs']."' WHERE cons_id='".$_POST['p_id']."'");
	}
	

?>