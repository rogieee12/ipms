<?php
	include'../connection.php';

	$q=mysqli_query($connection,"DELETE  FROM consumable WHERE cons_id='".$_POST['id']."'");
	
?>