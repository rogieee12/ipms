<?php
	include'../connection.php';
	// if($_POST['p_id']==''){
	// 	mysqli_query($connection,"INSERT into quescategory values (null,'".$_POST['Cat']."')");

	// }
	// else{
		mysqli_query($connection,"UPDATE scale set description='".$_POST['Desc']."' WHERE scale_id='".$_POST['p_id']."'");
	// }
	

?>