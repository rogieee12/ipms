<?php
include('connection.php');

if (isset($_POST['ac_id'])) {
    $ac_id = $_POST['ac_id'];  // Get the ac_id passed from AJAX

    // Query to fetch the accomplishment based on ac_id
    $query = "SELECT * FROM Accomplishment WHERE ac_id='" . mysqli_real_escape_string($connection, $ac_id) . "' ";
    $result = mysqli_query($connection, $query);

    // Check if there are results
    if (mysqli_num_rows($result) > 0) {
        // Start the modal HTML
        $modalHtml = '
        <div class="modal-header">
            <h4 class="modal-title">List of Accomplishments</h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <table id="example1" class="table table-bordered table-striped">
                <tbody>';

        // Fetch rows and generate table rows dynamically
        while ($rows = mysqli_fetch_array($result)) {
            // Palitan ang <li> ng newline, at alisin ang <ul>
            $clean_text = preg_replace('/<\/?ul>/', '', $rows[2]);  // Alisin ang <ul>
            $clean_text = preg_replace('/<\/?li>/', "\n", $clean_text);  // Palitan ang <li> ng line break
        
            $modalHtml .= '
                <tr>
                    <td style="white-space: pre-line;">' . htmlspecialchars($clean_text) . '</td>
                </tr>' . "\n";
        }
        
        // Close the table and modal HTML
        $modalHtml .= '
                </tbody>
            </table>
        </div>';

        // Output the modal HTML
        echo $modalHtml;
    } else {
        echo "No data found.";
    }
} else {
    echo "Invalid request.";
}
?>
