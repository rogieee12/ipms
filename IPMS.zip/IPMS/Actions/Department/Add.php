<?php
	include'../connection.php';
	if($_POST['p_id']==''){
		mysqli_query($connection,"INSERT into department values (null,'".$_POST['dept']."')");

	}
	else{
		mysqli_query($connection,"UPDATE department set department='".$_POST['dept']."' WHERE dept_id='".$_POST['p_id']."'");
	}
	

?>