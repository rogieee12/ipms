<?php
	include'../connection.php';

	mysqli_query($connection,"SELECT * FROM department WHERE dept_id='".$_POST['id']."'");
	
?>