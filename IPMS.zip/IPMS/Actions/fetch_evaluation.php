<?php
include('connection.php');

// Fetch evaluation questions
$questions = $connection->query("SELECT eq_id, question FROM evalquestions");

// Fetch responses for a specific student
$student_email = $_POST['id'];
$responses = $connection->query("SELECT eq_id, rating FROM responses WHERE student = '$student_email'");
$response_map = [];
while ($row = $responses->fetch_assoc()) {
    $response_map[$row['eq_id']] = $row['rating'];
}

// Generate table rows dynamically
$table_rows = '';
while ($question = $questions->fetch_assoc()) {
    $row = '<tr>';
    $row .= '<td>' . htmlspecialchars($question['question']) . '</td>';
    for ($i = 5; $i >= 1; $i--) {
        $checked = (isset($response_map[$question['eq_id']]) && $response_map[$question['eq_id']] == $i) ? 'checked' : '';
        $row .= '<td>
                    <div class="icheck-success d-inline">
                        <input type="radio" id="rating_' . $question['eq_id'] . '_' . $i . '" 
                               name="rating[' . $question['eq_id'] . ']" value="' . $i . '" ' . $checked . '>
                        <label for="rating_' . $question['eq_id'] . '_' . $i . '"></label>
                    </div>
                 </td>';
    }
    $row .= '</tr>';
    $table_rows .= $row;
}

echo $table_rows; // Output the table rows
?>
