<?php
include('../connection.php');

$sender = $_POST['sender'];
$receiver = $_POST['receiver'];


$r=mysqli_query($connection,"SELECT * FROM messages WHERE (sender='$sender' AND receiver='$receiver') OR (sender='$receiver' AND receiver='$sender') ORDER BY timestamp");

$messages = [];
while ($row = mysqli_fetch_array($r)) {
    $messages[] = $row;
}

echo json_encode($messages);
?>