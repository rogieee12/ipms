<?php
include('../connection.php');
$sender = $_POST['sender'];
$receiver = $_POST['receiver'];
$message = $_POST['message'];

 mysqli_query($connection,"INSERT INTO messages (sender, receiver, message) VALUES ('$sender', '$receiver', '$message')");

?>