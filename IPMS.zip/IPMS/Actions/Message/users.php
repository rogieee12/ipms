<?php
include('../connection.php');

$q=mysqli_query($connection,"SELECT * FROM accounts");
$users = [];

while ($row =  mysqli_fetch_array($q)) {
    $users[] = $row['username'];
}

echo json_encode($users);
?>