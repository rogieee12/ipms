<?php
  include'../connection.php';

  mysqli_query($connection,"UPDATE Accomplishment set status='3', remarks='".$_POST['rem']."' WHERE ac_id='".$_POST['id']."'");	
?>