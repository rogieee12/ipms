<?php
session_start();
include '../connection.php';

// Ensure session user exists
if (!isset($_SESSION['u'])) {
    die("Unauthorized access.");
}

// Get user details
$q = mysqli_prepare($connection, "SELECT * FROM accounts WHERE username = ?");
mysqli_stmt_bind_param($q, "s", $_SESSION['u']);
mysqli_stmt_execute($q);
$result = mysqli_stmt_get_result($q);
$rows = mysqli_fetch_array($result);

if (!$rows) {
    die("User not found.");
}

$username = $_SESSION['u'];
$xdate = $_POST['xdate'];
$accomplishment = $_POST['summernote'];
$crs_id = $rows[7];

// Check if accomplishment already exists
$check_stmt = mysqli_prepare($connection, "SELECT ac_id FROM accomplishment WHERE username = ? AND date_time = ?");
mysqli_stmt_bind_param($check_stmt, "ss", $username, $xdate);
mysqli_stmt_execute($check_stmt);
$check_result = mysqli_stmt_get_result($check_stmt);
$existing_accomplishment = mysqli_fetch_array($check_result);

if ($existing_accomplishment) {
    // Update existing record
    $update_stmt = mysqli_prepare($connection, "UPDATE accomplishment SET accomplishment = ?, remarks = '' WHERE ac_id = ?");
    mysqli_stmt_bind_param($update_stmt, "si", $accomplishment, $existing_accomplishment['ac_id']);
    mysqli_stmt_execute($update_stmt);
    mysqli_stmt_close($update_stmt);
    echo "Accomplishment updated successfully.";
} else {
    // Insert new record
    $insert_stmt = mysqli_prepare($connection, "INSERT INTO accomplishment VALUES (NULL, ?, ?, ?, '', ?, '1')");
    mysqli_stmt_bind_param($insert_stmt, "ssss", $username, $accomplishment, $xdate, $crs_id);
    mysqli_stmt_execute($insert_stmt);
    mysqli_stmt_close($insert_stmt);
    echo "Record inserted successfully.";
}

// Close statements and connection
mysqli_stmt_close($check_stmt);
mysqli_stmt_close($q);
mysqli_close($connection);
?>

