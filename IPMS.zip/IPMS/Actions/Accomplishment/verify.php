<?php
	include'../connection.php';
	mysqli_query($connection,"UPDATE Accomplishment set remarks='Very Good' WHERE ac_id='".$_POST['id']."'");
?>