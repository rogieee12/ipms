<?php
	include'../connection.php';
	// mysqli_query($connection,"DELETE FROM Accomplishment WHERE ac_id='".$_POST['id']."'");
	mysqli_query($connection,"UPDATE Accomplishment set status='2' WHERE ac_id='".$_POST['id']."'");
?>