<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../connection.php';

function generateRandomString($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return substr(str_shuffle(str_repeat($characters, ceil($length / strlen($characters)))), 0, $length);
}

if (isset($_FILES['Excel'])) {
    $file = $_FILES['Excel']['tmp_name'];
    if (($handle = fopen($file, mode: "r")) !== FALSE) {
        fgetcsv($handle); // Skip header row
        while (($data = fgetcsv($handle)) !== FALSE) {
            $IdNumber = $data[0];
            $username = $data[1];
            $lastname = $data[2];
            $firstname = $data[3];
            $middlename = $data[4];
            $suffix = $data[5];
            $gender = $data[6];
            $contact = $data[7];
            $BirthDate = $data[8];
            $guardian_name = $data[9]; 
            $contact_guardian = $data[10];
            $guardian_address = $data[11];
            $relationship = $data[12];
            $crs_desc = $data[13]; // Adjusted index
            $year = $data[14];
            $section = $data[15];
            
            // Fetch crs_id based on crs_desc
            $query = "SELECT crs_id FROM courses WHERE crs_desc = ? AND year = ? AND section = ?";
            $stmt = $connection->prepare($query);
            $stmt->bind_param("sss", $crs_desc, $year, $section);
            $stmt->execute();
            $stmt->bind_result($crs_id);
            $stmt->fetch();
            $stmt->close();
            
            if ($crs_id) {
                $randomPassword = generateRandomString(8); // Generate random password
            

                
                // Insert into security table (Auto Student Account)
                $stmt = $connection->prepare("INSERT INTO security (username, password, acctype) VALUES (?, ?, 'Student')");
$stmt->bind_param("ss", $username, $randomPassword);
$stmt->execute();
$stmt->close();

                // Insert into accounts table
                $sql = "INSERT INTO accounts (
                    IdNumber, username, lastname, firstname, middlename, suffix, gender, contact, 
                    BirthDate,  profile, crs_id, 
                    guardian_name, contact_guardian, guardian_address, relationship
                ) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, ?, ?)";

                $stmt = $connection->prepare($sql);
                $stmt->bind_param("ssssssssssssss", 
                    $IdNumber, $username, $lastname, $firstname, $middlename, $suffix, $gender, 
                    $contact, $BirthDate, $crs_id, 
                    $guardian_name, $contact_guardian, $guardian_address, $relationship);
                $stmt->execute();
                $stmt->close();
            } else {
                echo "Error: Course description '$crs_desc' not found.<br>";
            }
        }
        fclose($handle); 
        echo "CSV data imported successfully!";
    } else {
        echo "Error opening the file.";
    }
} else {
    echo "No file uploaded.";
}

$connection->close();
?>
