<?php
	include'../connection.php';

$username = $_POST['id']; // Assuming the username is coming from a POST request
$q=mysqli_query($connection,"SELECT security.username,security.password,security.acctype,courses.crs_desc FROM accounts INNER JOIN security ON accounts.username=security.username INNER JOIN courses ON accounts.crs_id=courses.crs_id WHERE security.username='$username'");

	
	$rows=mysqli_fetch_array($q);
	echo json_encode($rows);
?>
