<?php
include('connection.php');

// SQL Query (Fixed alias 'c' and replaced it with 'courses')
$sql = "SELECT courses.crs_desc, COUNT(accomplishment.ac_id) AS total_accomplishments
        FROM accomplishment 
        INNER JOIN accounts ON accounts.username = accomplishment.username
        INNER JOIN courses ON accomplishment.crs_id = courses.crs_id
        GROUP BY courses.crs_desc";

// Execute query and check for errors
$result = mysqli_query($connection, $sql);

if (!$result) {
    // Return an error if the query fails
    echo json_encode(["error" => "SQL Error: " . mysqli_error($connection)]);
    exit();
}

// Fetch data as an associative array
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Close database connection
mysqli_close($connection);

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($data);
?>
