<?php 
session_start();
include('connection.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $username = $_SESSION['u'];

        // Basahin ang file bilang binary data
        $imageData = file_get_contents($_FILES['image']['tmp_name']);
        $imageData = mysqli_real_escape_string($connection, $imageData);

        // MIME Type (optional pero recommended)
        $imageType = $_FILES['image']['type'];

        // Update query para sa profile image
        $sql = "UPDATE accounts SET profile='$imageData' WHERE username='$username'";

        if (mysqli_query($connection, $sql)) {
            echo "Profile image updated successfully.";
        } else {
            echo "Error updating profile: " . mysqli_error($connection);
        }
    } else {
        echo "Error: " . $_FILES['image']['error'];
    }
}
?>
