<?php 
session_start();
include'connection.php';
mysqli_query($connection,"UPDATE accounts set lastname='".$_POST['Lastname']."', firstname='".$_POST['Firstname']."', middlename='".$_POST['Middlename']."', gender='".$_POST['Gender']."', contact='".$_POST['Contact']."'  WHERE username='".$_SESSION['u']."'");


?>