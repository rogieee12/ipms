<?php
	include'../connection.php';
	// mysqli_query($connection,"DELETE FROM Accomplishment WHERE ac_id='".$_POST['id']."'");
	mysqli_query($connection,"UPDATE Accomplishment set status='1' WHERE ac_id='".$_POST['id']."'");
?>