<?php
	include'../connection.php';
	mysqli_query($connection,"UPDATE Accomplishment set remarks='".$_POST['Remarks']."' WHERE ac_id='".$_POST['p_id']."'");
?>