<?php
session_start();
include '../Actions/connection.php'; // Database connection

if (!isset($_SESSION['u'])) {
    die("Error: No user is logged in.");
}

if (isset($_POST['upload'])) {
    $username = $_SESSION['u'];

    // Basahin ang file bilang binary
    $imageData = file_get_contents($_FILES["profile"]["tmp_name"]);
    $imageData = mysqli_real_escape_string($connection, $imageData);

    $imageType = mime_content_type($_FILES["profile"]["tmp_name"]);

    // Check kung valid ang image
    $check = getimagesize($_FILES["profile"]["tmp_name"]);
    if ($check === false) {
        die("Error: The file is not an image.");
    }

    // Limit file size (max 1MB)
    if ($_FILES["profile"]["size"] > 1000000) {
        die("Error: Your file is too large (max 1MB).");
    }

    // Payagan lang ang JPG, JPEG, PNG, at GIF formats
    if (!in_array($imageType, ["image/jpg", "image/jpeg", "image/png", "image/gif"])) {
        die("Error: Only JPG, JPEG, PNG, and GIF files are allowed.");
    }

    // I-update ang `profile` field sa `accounts` table
    $sql = "UPDATE accounts SET profile = '$imageData' WHERE username = '$username'";
    if (mysqli_query($connection, $sql)) {
        header("Location: profile.php?upload_success=1");
        exit();
    } else {
        die("Error updating database: " . mysqli_error($connection));
    }
}
?>
