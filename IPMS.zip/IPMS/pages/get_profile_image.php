<?php
session_start();
include '../Actions/connection.php'; // Database connection

if (!isset($_SESSION['u'])) {
    die("Error: No user is logged in.");
}

$username = $_SESSION['u'];

// Kunin ang profile image mula sa database
$sql = "SELECT profile FROM accounts WHERE username = '$username'";
$result = mysqli_query($connection, $sql);
$row = mysqli_fetch_array($result);

if (!empty($row['profile'])) {
    // Output ang image data
    header("Content-Type: image/jpeg"); // Default MIME type
    echo $row['profile']; 
} else {
    // Mag-display ng default image kapag walang naka-upload
    header("Content-Type: image/png");
    readfile("../pages/default_profile.png");
}
?>
