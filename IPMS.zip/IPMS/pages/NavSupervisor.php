<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav class="mt-2">
    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Dashboard -->
        <li class="nav-item menu">
            <a href="../supervisorindex.php" class="nav-link <?php echo ($current_page == 'supervisorindex.php') ?'active':''; ?> ">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>Dashboard</p>
            </a>
        </li>

        <!-- Attendances -->
        <li class="nav-item">
            <a href="ViewAttendance.php" class="nav-link <?php echo ($current_page == 'ViewAttendance.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-calendar-check"></i>
                <p>Attendances</p>
            </a>
        </li>

        <!-- Student Intern -->
        <li class="nav-item">
            <a href="ListofStudentSupervisor.php" class="nav-link <?php echo ($current_page == 'ListofStudentSupervisor.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-user-graduate"></i>
                <p>Student Intern</p>
            </a>
        </li>

        <!-- Announcements -->
        <li class="nav-item">
            <a href="SupervisorAnnouncement.php" class="nav-link <?php echo ($current_page == 'SupervisorAnnouncement.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-bullhorn"></i>
                <p>Announcements</p>
            </a>
        </li>

        <!-- Accomplishments -->
        <li class="nav-item">
            <a href="ApproveAccomplishment.php" class="nav-link <?php echo ($current_page == 'ApproveAccomplishment.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-tasks"></i>
                <p>Accomplishments</p>
            </a>
        </li>

        <!-- Evaluate Student -->
        <li class="nav-item">
            <a href="StudentsUnderSupervisor.php" class="nav-link <?php echo ($current_page == 'StudentsUnderSupervisor.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-clipboard-check"></i>
                <p>Evaluate Student</p>
            </a>
        </li>

        <!-- Chat Coordinator -->
        <li class="nav-item">
            <a href="ChatSupervisor.php" class="nav-link <?php echo ($current_page == 'ChatSupervisor.php') ?'active':''; ?>">
                <i class="nav-icon fas fa-comments"></i>
                <p>Chat Coordinator</p>
            </a>
        </li>

        <li class="nav-item">
            <a href="../Actions/logout.php" class="nav-link">
            <i class="nav-icon fas fa-sign-out-alt"></i>
                <p>LogOut</p>
            </a>
        </li>
        </li>
    </ul>
</nav>