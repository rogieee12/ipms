<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<nav class="mt-2">
  <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    <li class="nav-item menu">
      <a href="../coordinatorindex.php" class="nav-link <?php echo ($current_page == 'coordinatorindex.php') ?'active':''; ?> ">
        <i class="nav-icon fas fa-tachometer-alt"></i>
        <p>Dashboard</p>
      </a>
    </li>
    
    <li class="nav-item">
      <a href="#" class="nav-link <?php echo ($current_page == 'Consumables2.php'  || $current_page == 'Category.php' || $current_page == 'EvaluationQuestion.php' || $current_page == 'Scale.php' ) ?'active':''; ?>">
        <i class="nav-icon fas fa-cogs"></i>
        <p>Setup <i class="fas fa-angle-left right"></i></p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="Consumables2.php" class="nav-link <?php echo ($current_page == 'Consumables2.php') ?'active':''; ?>">
            <i class="fas fa-clock nav-icon"></i>
            <p>Rendered Hour</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="Category.php" class="nav-link <?php echo ($current_page == 'Category.php') ?'active':''; ?>">
            <i class="fas fa-tags nav-icon"></i>
            <p>Category</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="EvaluationQuestion.php" class="nav-link <?php echo ($current_page == 'EvaluationQuestion.php') ?'active':''; ?>">
            <i class="fas fa-list nav-icon"></i>
            <p>Evaluation Matrix</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="Scale.php" class="nav-link <?php echo ($current_page == 'Scale.php') ?'active':''; ?>">
            <i class="fas fa-balance-scale nav-icon"></i>
            <p>Scale</p>
          </a>
        </li>
      </ul>
    </li>
    
    <li class="nav-item">
      <a href="AssignStudent.php" class="nav-link <?php echo ($current_page == 'AssignStudent.php') ?'active':''; ?>">
        <i class="fas fa-user-graduate nav-icon"></i>
        <p>Deploy Interns</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="ClassToAnnounce.php" class="nav-link <?php echo ($current_page == 'ClassToAnnounce.php') ?'active':''; ?>">
        <i class="fas fa-bullhorn nav-icon"></i>
        <p>Announcement</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="Chat.php" class="nav-link <?php echo ($current_page == 'Chat.php') ?'active':''; ?>">
        <i class="fas fa-comments nav-icon"></i>
        <p>Chat</p>
      </a>
    </li>
    
    <li class="nav-item">
    <a href="#" class="nav-link <?php echo ($current_page == 'Listofstudents.php'  || $current_page == 'ViewAccomplishment.php' || $current_page == 'ReviewAccomplishment.php' || $current_page == '' ) ?'active':''; ?>">
        <i class="nav-icon fas fa-chart-bar"></i>
        <p>Reports <i class="fas fa-angle-left right"></i></p>
      </a>
      <ul class="nav nav-treeview">
        <li class="nav-item">
          <a href="Listofstudents.php" class="nav-link <?php echo ($current_page == 'Listofstudents.php') ?'active':''; ?>">
            <i class="fas fa-users nav-icon"></i>
            <p>Student Intern</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="ViewAccomplishment.php" class="nav-link <?php echo ($current_page == 'ViewAccomplishment.php') ?'active':''; ?>">
            <i class="fas fa-trophy nav-icon"></i>
            <p>Accomplishment</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="ReviewEvaluation.php" class="nav-link <?php echo ($current_page == 'ReviewEvaluation.php') ?'active':''; ?>">
            <i class="fas fa-star nav-icon"></i>
            <p>Evaluation</p>
          </a>
        </li>
      </ul>
    </li>
    
    <li class="nav-item">
      <a href="../Actions/logout.php" class="nav-link">
        <i class="fas fa-sign-out-alt nav-icon"></i>
        <p>Logout</p>
      </a>
    </li>
  </ul>
</nav>