<?php
session_start();
include('../Actions/connection.php');

if (!isset($_SESSION['u']) || $_SESSION['u'] == '') {
    header("location:../login.php");
    exit();
}

// Kunin ang security details
$q = mysqli_query($connection, "SELECT * FROM security WHERE username='" . $_SESSION['u'] . "'");
$rows = mysqli_fetch_array($q);

// Kunin ang accounts details + Courses Info
$r = mysqli_query($connection, 
    "SELECT accounts.*, courses.crs_desc, courses.year, courses.section 
     FROM accounts 
     LEFT JOIN courses ON accounts.crs_id = courses.crs_id 
     WHERE accounts.username='" . $_SESSION['u'] . "'");

$rowsR = mysqli_fetch_array($r);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IPMS | Profile</title>


  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/adminlte.min.css">  
   <!-- SweetAlert2 -->
  <link rel="stylesheet" href="../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="../plugins/toastr/toastr.min.css">
  <!-- summernote -->
  <link rel="stylesheet" href="../plugins/summernote/summernote-bs4.min.css">
    <!-- SimpleMDE -->
  <link rel="stylesheet" href="../plugins/simplemde/simplemde.min.css">
</head>
<style>
  .sidebar-dark-primary{
    background-color: #002147 !important;
  }
  .navbar-white{
    background-color: #507d2a !important;
    
  }
</style>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
   
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>

      <li class="nav-item dropdown">
    <a href="#" class="nav-link dropdown-toggle" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="nav-icon fas fa-user"></i>
       
    </a>
    <div class="dropdown-menu" aria-labelledby="userDropdown">
        <a class="dropdown-item" href="pages/profile.php">Profile</a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item text-danger" href="#" id="logoutBtn">Logout</a>
    </div>
</li>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.getElementById("logoutBtn").addEventListener("click", function(event) {
        event.preventDefault(); // Prevent default logout action

        Swal.fire({
            title: "Are you sure?",
            text: "You will be logged out.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, log me out!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "Actions/logout.php"; // Redirect to logout page
            }
        });
    });
</script>
      
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
      <img src="../dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">IPMS</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="profile.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
       <?php 
            $acc=mysqli_query($connection,"SELECT * FROM accounts WHERE username='".$_SESSION['u']."'");
            $rows=mysqli_fetch_array($acc);
          ?>
          <a href="#" class="d-block"><?php echo $rows[3]." ".substr($rows[4],0,1)." . ".$rows[2];?></a>
        </div>
      </div>

      <?php
  include ('C:\xampp\htdocs\IPMS\pages\NavStudent.php');
  ?>


    </div>
    <!-- /.sidebar -->
  </aside>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
             
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
      <div class="col-md-14">
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="profile.png"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center"><?php echo $rowsR[3]." ".substr($rows[4],0,1). ". ".$rowsR[2];; ?></h3>
              </div>
              <!-- /.card-body -->
            </div>
    </section>
    <div class="row">
    <div class="col-12 col-sm-12">
        <div class="card card-success card-tabs">
            <div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="requirements-tab" data-bs-toggle="tab" href="#requirements" role="tab" aria-controls="requirements" aria-selected="false">Internship Requirements</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="dtr-tab" data-bs-toggle="tab" href="#dtr" role="tab" aria-controls="dtr" aria-selected="false">View DTR</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="evaluation-tab" data-bs-toggle="tab" href="#evaluation" role="tab" aria-controls="evaluation" aria-selected="false">Evaluation</a>
                    </li>
                </ul>
            </div>

            <style>
              .form-control {
             background-color: white !important;
        }
    /* Screen styling */
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
    }
        /* Hide the element when printing */
@media print {
    .nav-item {
        display: none !important;
    }
}

        .requirments{
         display: none;
}
    table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Add shadow for modern look */
        border-radius: 8px; /* Rounded corners */
        overflow: hidden; /* Ensure rounded corners are visible */
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: rgb(238, 238, 238); /* Light gray header background */
        color: black; /* Black text for headers */
        font-weight: bold;
        text-align: center; /* Center-align headers */
    }
    tr:nth-child(even) {
        background-color: #f9f9f9; /* Alternate row color */
    }
    tr:hover {
        background-color: #f1f1f1; /* Hover effect for rows */
    }
    .total-row {
        background-color: #e9ecef; /* Light gray background for total row */
        font-weight: bold;
    }
    .print-button {
        margin: 10px 0;
        padding: 10px 20px;
        background-color: rgb(4, 166, 48);
        color: white;
        border: none;
        cursor: pointer;
        font-size: 16px;
        border-radius: 5px; /* Rounded corners for button */
    }
    .print-button:hover {
        background-color: #0056b3;
    }
    .logo {
        display: none; /* Hide logo on screen */
    }

    /* Print styling */
    @media print {
        body {
            width: 100%;
            margin: 0;
            padding: 0;
            font-size: 10px;
        }
        table {
            box-shadow: none; /* Remove shadow for printing */
            border-radius: 0; /* Remove rounded corners for printing */
        }
        th {
            background-color: rgb(238, 238, 238) !important; /* Ensure header color is printed */
            color: black !important;
        }
        tr:nth-child(even) {
            background-color: transparent !important; /* Remove alternating row colors */
        }
        tr:hover {
            background-color: transparent !important; /* Remove hover effects */
        }
        .print-button, .no-print {
            display: none; /* Hide the print button and other non-printable elements */
        }
        .logo {
            display: block; /* Show logo only when printing */
            text-align: center; /* Center the logo */
            margin-bottom: 20px; /* Add space below the logo */
        }
        .logo img {
            width: 350px; /* Adjust logo size */
            height: auto;
        }
    }

    table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Add shadow for modern look */
    border: 2px solid black; /* Add border for clarity */
}

th, td {
    padding: 10px;
    text-align: center;
    border: 1px solid black; /* Add border lines to all cells */
}

th {
    background-color: rgb(238, 238, 238); /* Light gray header background */
    color: black; /* Black text for headers */
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9; /* Alternate row color */
}

tr:hover {
    background-color: #f1f1f1; /* Hover effect for rows */
}

.total-row {
    background-color: #e9ecef; /* Light gray background for total row */
    font-weight: bold;
}

</style>
            <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                    <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <!-- Profile content here -->
                        <p>
                        <form id="studentForm">
  <div class="row">
    <div class="col-md-3">
      <div class="form-group">
        <label>Student ID</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[0]); ?>" id="IdNumber" name="IdNumber" placeholder="Student ID" readonly>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-3">
      <div class="form-group">
        <label>Last Name</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[2]); ?>" id="lastname" name="lastname" placeholder="Last Name" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>First Name</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[3]); ?>" id="firstname" name="firstname" placeholder="First Name" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Middle Name</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[4]); ?>" id="middlename" name="middlename" placeholder="Middle Name" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Suffix</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[5]); ?>" id="suffix" name="suffix" placeholder="Suffix" readonly>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-md-3">
      <div class="form-group">
        <label>Sex</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[6]); ?>" id="gender" name="gender" placeholder="Sex" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Birth Date</label>
        <input type="date" class="form-control" value="<?php echo date('Y-m-d', strtotime($rowsR[8])); ?>" id="BirthDate" name="BirthDate" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Age</label>
        <input type="text" class="form-control" id="age" name="age" placeholder="Age" readonly>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      let birthDateInput = document.getElementById("BirthDate");
      let ageInput = document.getElementById("age");

      function calculateAge(birthDate) {
        let today = new Date();
        let birthDateObj = new Date(birthDate);
        let age = today.getFullYear() - birthDateObj.getFullYear();
        let monthDiff = today.getMonth() - birthDateObj.getMonth();

        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDateObj.getDate())) {
          age--;
        }
        return age;
      }

      if (birthDateInput.value) {
        ageInput.value = calculateAge(birthDateInput.value);
      }
    });
  </script>

  <div class="row">
    <div class="col-md-4">
      <div class="form-group">
        <label>Course</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR['crs_desc']); ?>" id="crs_desc" name="crs_desc" placeholder="Course Description" readonly>
      </div>
    </div>
    <div class="col-md-2">
      <div class="form-group">
        <label>Level</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR['year']); ?>" id="year" name="year" placeholder="Year Level" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Section</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR['section']); ?>" id="section" name="section" placeholder="Section" readonly>
      </div>
    </div>
    <div class="col-md-3">
      <div class="form-group">
        <label>Contact Number</label>
        <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[7]); ?>" id="contact" name="contact" placeholder="Contact Number" readonly>
      </div>
    </div>
  </div>

  <div class="col-md-3">
    <div class="form-group">
      <label>Address</label>
      <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[12]); ?>" id="address" name="address" placeholder="Address" readonly>
    </div>
  </div>

  <div class="col-md-4">
    <div class="form-group">
      <label>Email Address</label>
      <input type="email" class="form-control" value="<?php echo htmlspecialchars($rowsR[1]); ?>" id="email" name="email" placeholder="Email Address" readonly>
    </div>
  </div>
  

  <h3 class="mt-4">Parents/Guardian Information</h3>
  <div class="form-group">
    <label>Name</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[10]); ?>" id="guardian_name" name="guardian_name" placeholder="Guardian Name" readonly>
  </div>

  <div class="form-group">
    <label>Contact Number</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[11]); ?>" id="contact_guardian" name="contact_guardian" placeholder="Guardian Contact Number" readonly>
  </div>

  <div class="form-group">
    <label>Address</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[12]); ?>" id="guardian_address" name="guardian_address" placeholder="Guardian Address" readonly>
  </div>

  <div class="form-group">
    <label>Relationship</label>
    <input type="text" class="form-control" value="<?php echo htmlspecialchars($rowsR[13]); ?>" id="relationship" name="relationship" placeholder="Relationship" readonly>
  </div>
</form>



                        </p>
                    </div>
                    <div class="tab-pane fade" id="requirements" role="tabpanel" aria-labelledby="requirements-tab">
                        <!-- Internship Requirements content here -->
                        <p>
                        <div class="form-group">
<h3 class="mb-0">📂 Internship Requirements </h3>
</div>
<div class="card-body">
<form id="uploadForm">
<div class="form-group">
<!-- Internship Application Form -->
<div class="mb-3">
<div class="input-group">
<input type="text" class="form-control" id="internshipForm" name="requirement_name" value="Internship Application Form" readonly>
<button class="btn btn-success uploadBtn" type="button">Attach <i class="fas fa-paperclip"></i></button>
<input type="file" class="fileInput d-none" accept="image/*">
</div>
<div class="mt-2 d-flex align-items-center">
<img class="previewImage d-none" src="#" alt="Image Preview" style="max-width: 150px; border-radius: 10px;">
<button class="btn btn-danger btn-sm removeBtn d-none ms-2">Remove</button>
</div>
</div>

<!-- Parental Consent -->
<div class="mb-3">
<div class="input-group">
<input type="text" class="form-control" id="parentalConsent" name="requirement_name" value="Parental Consent" readonly>
<button class="btn btn-success uploadBtn" type="button">Attach <i class="fas fa-paperclip"></i></button>
<input type="file" class="fileInput d-none" accept="image/*">
</div>
<div class="mt-2 d-flex align-items-center">
<img class="previewImage d-none" src="#" alt="Image Preview" style="max-width: 150px; border-radius: 10px;">
<button class="btn btn-danger btn-sm removeBtn d-none ms-2">Remove</button>
</div>
</div>

<!-- Medical Certificate -->
<div class="mb-3">
<div class="input-group">
<input type="text" class="form-control" id="medicalCertificate" name="requirement_name" value="Medical Certificate" readonly>
<button class="btn btn-success uploadBtn" type="button">Attach <i class="fas fa-paperclip"></i></button>
<input type="file" class="fileInput d-none" accept="image/*">
</div>
<div class="mt-2 d-flex align-items-center">
<img class="previewImage d-none" src="#" alt="Image Preview" style="max-width: 150px; border-radius: 10px;">
<button class="btn btn-danger btn-sm removeBtn d-none ms-2">Remove</button>
</div>
</div>


</div>
</form>
</div>

<script>
document.querySelectorAll('.uploadBtn').forEach((button, index) => {
button.addEventListener('click', function() {
document.querySelectorAll('.fileInput')[index].click();
});
});

document.querySelectorAll('.fileInput').forEach((input, index) => {
input.addEventListener('change', function(event) {
const file = event.target.files[0];
if (file) {
const reader = new FileReader();
reader.onload = function(e) {
const preview = document.querySelectorAll('.previewImage')[index];
const removeBtn = document.querySelectorAll('.removeBtn')[index];

preview.src = e.target.result;
preview.classList.remove('d-none'); 
removeBtn.classList.remove('d-none'); 
};
reader.readAsDataURL(file);
}
});
});

document.querySelectorAll('.removeBtn').forEach((button, index) => {
button.addEventListener('click', function() {
const preview = document.querySelectorAll('.previewImage')[index];
const fileInput = document.querySelectorAll('.fileInput')[index];

preview.src = "#";
preview.classList.add('d-none'); 
button.classList.add('d-none'); 
fileInput.value = ""; 
});
});

document.getElementById('uploadForm').addEventListener('submit', function(e) {
e.preventDefault();
const formData = new FormData();

document.querySelectorAll('.fileInput').forEach((input, index) => {
if (input.files.length > 0) {
formData.append('file', input.files[0]);
formData.append('requirement_name', document.querySelectorAll('.form-control')[index].value);
}
});

fetch('upload.php', {
method: 'POST',
body: formData
}).then(response => response.json())
.then(data => {
if (data.status === "success") {
alert("File uploaded successfully!");
} else {
alert("Error: " + data.message);
}
}).catch(error => console.log(error));
});
</script>
                        </p>
                    </div>
                    <div class="tab-pane fade" id="dtr" role="tabpanel" aria-labelledby="dtr-tab">
                        <!-- View DTR content here -->
                        <p>
                          

<button class="print-button" onclick="window.print()">Print</button>
<div class="logo">
        <img src="../f2.jpg" alt="Company Logo">
        <br>
        <br>
        <br>
     
        <h3>Daily Time Record</h3>
        <br>    
        <h3 class="profile-username text-center"><?php echo $rowsR[3]." " .$rowsR[4]." " .$rowsR[2];?></h3>
        

      </div>
       <?php  
// Check if the user is logged in (session variable 'u' is set)
if (isset($_SESSION['u'])) {
    $username = $_SESSION['u']; // Get the username from the session

    // Check if the username is not empty
    if (!empty($username)) {
        // Query to get the attendance of the user
        $query = "SELECT * FROM attendance WHERE username = ?";
        $stmt = mysqli_prepare($connection, $query);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $username); // Use the username from the session
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            // Check if there are any results
            if (mysqli_num_rows($result) > 0) {
                $totalHours = 0; // Initialize total hours worked
                

                // Start the table
                echo '<table>';
                echo ' <tr>
            <th rowspan="2">Date</th>
            <th colspan="2">AM</th>
            <th colspan="2">PM</th>
            <th colspan="2">UnderTime</th>
            <th rowspan="2">Hours Rendered</th>
        </tr>
        <tr>
            <th>Arrival</th>
            <th>Departure</th>
            <th>Arrival</th>
            <th>Departure</th>
            <th>Hours</th>
            <th>Minutes</th>
        </tr>';

                while ($row = mysqli_fetch_assoc($result)) {
                    // Calculate time worked for AM
                    $timeInAM = strtotime($row['time_in_AM']);
                    $timeOutAM = strtotime($row['time_out_AM']);
                    $hoursAM = ($timeOutAM - $timeInAM) / 3600; // Convert seconds to hours

                    // Calculate time worked for PM
                    $timeInPM = strtotime($row['time_in_PM']);
                    $timeOutPM = strtotime($row['time_out_PM']);
                    $hoursPM = ($timeOutPM - $timeInPM) / 3600; // Convert seconds to hours

                    // Calculate time worked for Extended Time
                    $timeInExt = strtotime($row['Ext_IN']);
                    $timeOutExt = strtotime($row['Ext_OUT']);
                    $hoursExt = ($timeOutExt - $timeInExt) / 3600; // Convert seconds to hours

                    // Add to total hours
                    $totalHours += $hoursAM + $hoursPM + $hoursExt;

                    // Display the row
                    echo '<tr>
                            <td>' . htmlspecialchars($row['d_date']) . '</td>
                            <td>' . htmlspecialchars($row['time_in_AM']) . '</td>
                            <td>' . htmlspecialchars($row['time_out_AM']) . '</td>
                            <td>' . htmlspecialchars($row['time_in_PM']) .  '</td>
                            <td>' . htmlspecialchars($row['time_out_PM']) . '</td>
                            <td>' . htmlspecialchars($row['Ext_IN']) . '</td>
                            <td>' . htmlspecialchars($row['Ext_OUT']) . '</td>
                            
                            <td style="text-align: center;">' . number_format($hoursAM + $hoursPM + $hoursExt, 2) . ' hours</td>
                          </tr>';
                }

                // Display total hours worked
                echo '<tr class="total-row">
                        <td colspan="7" style="text-align: right;"><strong>TOTAL:</strong></td>
                        <td style="text-align: center;"><strong>' . number_format($totalHours, 2) . ' hours</strong></td>
                      </tr>';

                // End the table
                echo '</table>';
            } else {
                echo "<p class='no-print'>No attendance record found for this user.</p>";
            }
        } else {
            echo "<p class='no-print'>Database query failed.</p>";
        }
    } else {
        echo "<p class='no-print'>Username not found in session.</p>";
    }
} else {
    echo "<p class='no-print'>User not logged in. Please log in to view attendance.</p>";
}
?>





                  </tbody>
               
                </table>
              </div>
    </section>
    <script src="../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/adminlte.min.js"></script>
    <!-- /.content -->

<!-- modal -->

<!-- modal -->
                        </p>
                      
                    <div class="tab-pane fade" id="evaluation" role="tabpanel" aria-labelledby="evaluation-tab">
                        <p>
                          Evaluation content goes here.
                        </p>
                   
     

   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </div>


</body>
</html>

