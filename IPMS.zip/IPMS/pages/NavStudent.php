<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>


<nav class="mt-2">
<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
    <!-- Dashboard -->
    <li class="nav-item menu">
        <a href="../studentindex.php" class="nav-link <?php echo ($current_page == 'studentindex.php') ?'active':''; ?> ">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Dashboard</p>
        </a>
    </li>

    <!-- Attendance -->
    <li class="nav-item">
        <a href="Attendance.php" class="nav-link  <?php echo ($current_page == 'Attendance.php') ?'active':''; ?>">
            <i class="nav-icon fas fa-calendar-check"></i>
            <p>Attendance</p>
        </a>
    </li>

    <!-- Announcement -->
    <li class="nav-item">
        <a href="AnnouncementStudent.php" class="nav-link  <?php echo ($current_page == 'AnnouncementStudent.php') ?'active':''; ?>">
            <i class="nav-icon fas fa-bullhorn"></i>
            <p>Announcement</p>
        </a>
    </li>

    <!-- Accomplishment -->
    <li class="nav-item">
        <a href="Accomplishment.php" class="nav-link  <?php echo ($current_page == 'Accomplishment.php') ?'active':''; ?>">
            <i class="nav-icon fas fa-tasks"></i>
            <p>Accomplishment</p>
        </a>
    </li>
   

    <!-- Logout -->
   
</ul>
</nav>
