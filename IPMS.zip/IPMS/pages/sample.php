<?php
include('../Actions/connection.php');
$questions = $connection->query("SELECT eq_id, question FROM evalquestions");

$student_email = 'student@gmail.com';
$responses = $connection->query("SELECT eq_id, rating FROM responses WHERE student = '$student_email'");
$response_map = [];
while ($row = $responses->fetch_assoc()) {
    $response_map[$row['eq_id']] = $row['rating'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Table</title>
</head>
<body>
    <form id="evaluationForm" method="POST" action="save_evaluation.php">
        <table border="1">
            <thead>
                <tr>
                    <th>Description</th>
                    <th>5</th>
                    <th>4</th>
                    <th>3</th>
                    <th>2</th>
                    <th>1</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($question = $questions->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($question['question']); ?></td>
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <td>
                                <input
                                    type="radio"
                                    name="rating[<?= $question['eq_id']; ?>]"
                                    value="<?= $i; ?>"
                                    <?= isset($response_map[$question['eq_id']]) && $response_map[$question['eq_id']] == $i ? 'checked' : ''; ?>
                                >
                            </td>
                        <?php endfor; ?>
                    </tr>
                 <?php endwhile; ?>
            </tbody>
        </table>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
