<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>IPMS | Log in</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="plugins/toastr/toastr.min.css">
</head>
<style>
  /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    height: 100vh;
    display: flex;
    flex-direction: row;
    overflow: hidden;
    margin: 0;
}

/* Left Section: Background Image */
.left-section {
    flex: 1.5; /* Increase the flex value to make it larger */
    background: url('saint.png') no-repeat center center;
    background-size: cover;
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    padding: 30px;
    color: green;
    text-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
    height: 100vh;
}

.left-section .college-name {
    font-size: 2rem;
    font-weight: bold;
    margin-bottom: 10px;
}

.left-section .tagline {
    font-size: 1.2rem;
    margin-bottom: 40px;
}

/* Right Section: Login Form */
.right-section {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: white;
    padding: 30px;
    height: 100vh;
}

.login-box {
    width: 100%;
    max-width: 400px;
    padding: 20px;
    background-color: rgba(255, 255, 255, 0.95); /* Semi-transparent white */
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.login-logo {
    text-align: center;
    margin-bottom: 20px;
}

.login-logo b {
    color: black;
    font-size: 15px;
}

.card {
    border: none;
    background: none;
}

.card-body {
    width: 100%;
}

.login-box-msg {
    margin-bottom: 15px;
    font-size: 1.2rem;
    color: #333;
    text-align: center;
}

/* Input Fields */
.input-group {
    margin-bottom: 20px;
}

.input-group .form-control {
    border-radius: 5px;
    border: 1px solid #ccc;
    padding: 10px;
    font-size: 1rem;
}

.input-group .input-group-text {
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 0 5px 5px 0;
}

/* Button Styling */
.btn-primary {
    width: 100%;
    padding: 10px;
    font-size: 1rem;
    background-color: #28a745;
    border: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
    margin-top: auto;
    left: 170px;
   
   
}

.btn-primary:hover {
    background-color: #218838;
}
h1{
    font-size: 25px;
    margin-bottom: 50px;
}
img{
    width: 100px;   
}
h2{
    font-weight: 10px;
    font-size:15px;
    margin-bottom: 0;
}






</style>
<body>
    <div class="left-section">
        <div class="college-name"></div>
        <div class="tagline"></div>
    </div>

    <div class="right-section">
        <div class="login-box">
            <div class="login-logo">
            <img src="sjcb logo.png" alt="Description of the image" id="img">
                <h1>Saint Joseph College of Baggao</h1>
                <h3>Welcome</h3>
               <h2>INTERNSHIP PROGRAM MONITORING SYSTEM</h2>
            </div>
            <div class="card">
                <div class="card-body login-card-body">
                    <p class="login-box-msg"></p>

                    <form>
                        <div class="input-group mb-3">
                            <input type="email" class="form-control" name="username" id="username" placeholder="Email">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-3">
                            <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-4">
                                <button type="button" class="btn btn-primary btn-block" id="sign">Log in</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>


<!-- /.login-box -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- SweetAlert2 -->
<script src="plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="plugins/toastr/toastr.min.js"></script>
</body>
</html>
<script>
  $(document).ready(function(){
    
    $("#sign").click(function(){
      var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
      });

      var username=$("#username").val();
      var password=$("#password").val();
      $.ajax({
        url:'Actions/login.php',
        data:{username:username,password:password},
        type:'POST',
        success:function(data){
          //alert(data);
          if(data==='A'){
            window.location.href='index.php';
          }
          
          if(data==='B'){
            window.location.href='CoordinatorIndex.php';
          }

          if(data==='C'){
            window.location.href='supervisorindex.php';
          }

          if(data==='S'){
            window.location.href='studentindex.php';
          }
          
          else if(data==='D'){
             Toast.fire({
              icon: 'error',
              title: 'Wrong Credentials. Try Again'
             })
          } 
        }
      });
    });
  });
</script>